<div class="jumbotron">	
	<h2> Hegycsúcsok</h2>
	
	<p>A mai dátum: <?php print(date('Y. M. j.')); ?></p>
	<p>készítette : ...</p>
</div>