Akadémikusok 

A Magyar Tudományos Akadémia (MTA) magyarországi tudományos köztestület, amelynek fő feladata a tudomány művelése, 
	a tudomány eredményeinek terjesztése, a magyar tudomány képviselete.

Egy magyar tudományos társaság alapításának gondolatához már az 1700-as évek második felében Bél Mátyás evangélikus lelkész 
	és polihisztor is eljutott. Néhány évtized múlva, 1781-ben Bessenyei György pedig papírra is vetette saját elképzelését. 
	Az 1791. évi országgyűlés tudományi bizottsága felvette programjába a katonai és képzőművészeti akadémián kívül egy magyar 
	tudományos akadémia felállítását,
	 ám a tervek megvalósítása végül I. Ferenc uralkodásának első három évtizedében elmaradt.

Az 1825-ös pozsonyi országgyűlésen (a követek november 2-ai és 3-ai kerületi ülésén) ennek eszméjét ismét fölelevenítették.
			Már az első gyűlésen, november 2-án, szóvá tette egy magyar tudományos intézet felállításának szükségességét
			Máriássy Sáros vármegyei követ.