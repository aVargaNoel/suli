<div>
    <h1>Notebook gyártók</h1>
    <div>
        <img src="img/assus.jpg" alt="assus" >
        <p>ASUS : tajvani multinacionális vállalat, amely számítástechnikai eszközök előállításával
            foglalkozik. Ez a vállalat birtokolja a legnagyobb szabad számítógép-kereskedelmi láncot Tajpejben.</p>
    </div>
    <div>
        <img src="img/HP.png" alt="hp" >
        <p>HP : jelenleg a világ legnagyobb IT-vállalata, amely a PC-iről és nyomtatóiról lett világhírű.
            Központja a kaliforniai Palo Altóban van, de világszerte képviseli magát a számítógépes, nyomtatási,
            fényképészeti termékeivel, valamint a kapcsolódó szoftverekkel és szolgáltatásokkal.</p>
    </div>
    <div>
        <img src="img/fujitsu.jpg" alt="fujitsu" >
        <p>FUJITSU : egy 1935-ben alapított japán multinacionális információs és kommunikációs technológiai
            berendezéseket és szolgáltatásokat nyújtó vállalat, amelynek székhelye Tokióban van.2021-ben a Fujitsu a
            világ hatodik legnagyobb IT-szolgáltatója éves bevétel alapján, és a legnagyobb Japánban.</p>
    </div>
    <div>
        <img src="img/dell.jpg" alt="dell" >
        <p>DELL : egy, az USA Texas államában, lévő székhelyű számítógépes hardvertervező és -gyártó vállalat.
            Jelmondata a „Get more out of now”, magyarul: „hozzunk ki többet a mából”. 1984-ben alapították.Világszerte
            körülbelül 55 000 embert foglalkoztat. Árbevétele 2004-ben elérte a 49,2 milliárd dollárt.</p>
    </div>
    <div>
        <img src="img/lenovo.jpg" alt="lenovo" >
        <p>LENOVO : kínai vállalat, a világ vezető személyi számítógép gyártója.Az eladott darabszámokat
            illetően a 2012-es évben maga mögé utasította a korábbi világelső Hewlett-Packardot.A vállalatot 1984-ben
            alapította egy 11 tervezőmérnökből álló csapat – Legend néven – Pekingben. 2005-ben a Lenovo megvette az IBM
            PC divízióját. Cégközpontjaik az amerikai Észak-Karolina állambeli Morrisville, a kínai Peking, valamint
            Szingapúr.</p>
    </div>
    <div>
        <img src="img/MSI.jpg" alt="msi" >
        <p>MSI :Micro-Star International egy tajvani multinacionális információtechnológiai vállalat, amelynek
            központja a tajvani Új-Tajpej városában található. Számítógépes hardvert, kapcsolódó termékeket és
            szolgáltatásokat tervez, fejleszt és biztosít, beleértve a laptopokat, asztali számítógépeket, alaplapokat,
            grafikus kártyákat, többfunkciós számítógépeket, szervereket, ipari számítógépeket, PC-perifériákat, autós
            infotainment termékeket stb.</p>
    </div>
</div>